  <!-- Footer -->
  <div id="footer">
    <p class="left"> <a href="index.php">Home</a> <span>|</span> <a href="register.php">Register</a> <span>|</span> <a href="admin.php">Admin Login</a> <span>|</span> <a href="shop.php">The Store</a> <span>|</span> <a href="contact.php">Contact</a> </p>
    <p class="right"></p>
  </div>
  <!-- End Footer -->