<div class="box categories">
        <h2>Categories <span></span></h2>
        <div class="box-content">
          <ul>
            <li><a href="shop.php?cat=towel">towel</a></li>
            <li><a href="shop.php?cat=bedsheet">bedsheet</a></li>
			<li><a href="shop.php?cat=screen">screen</a></li>
			<li><a href="shop.php?cat=doormate">doormate</a></li>
			<li><a href="shop.php?cat=pillow-cover">pillow cover</a></li>
          </ul>
        </div>
      </div>