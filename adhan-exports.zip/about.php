<?php
include "config.php";
include "header.php";
?>
  <!-- Main -->
  <div id="main">
    <div class="cl">&nbsp;</div>
    <!-- Content -->
    <div id="content">
      <!-- Content Slider -->
      <div id="slider" class="box">
        <div id="slider-holder">
          <ul>
            <li><a href="#"><img src="css\images\slide2.jpg" alt="" /></a></li>
            <li><a href="#"><img src="css\images\slide1.jpg" alt="" /></a></li>
            <li><a href="#"><img src="css\images\slide3.jpg" alt="" /></a></li>
			<li><a href="#"><img src="css\images\slide4.jpg" alt="" /></a></li>
			<li><a href="#"><img src="css\images\slide5.jpg" alt="" /></a></li>
          </ul>
        </div>
        <div id="slider-nav"> <a href="#" class="active">1</a> <a href="#">2</a> <a href="#">3</a><a href="#">4</a><a href="#">5</a> </div>
      </div>
	        <div class="products">
        <div class="cl">&nbsp;</div>
          <div class="box search">
        <h2>About Us </h2>
        <div class="box-content">

<p>Adhan exports is a leading fabric textile manufacturer located in Karur.The company was started in the year 2017.We are professional excels in manufacturing great quality  products.Our motto is to provide the high quality products on time at the best price to customers.We offer variety of Home Textile products made out of finest cotton fabrics and various other blends in various sizes, innovative designs & attractive colors.Contact us for more details!</p>       

</div>
      </div>
        <div class="cl">&nbsp;</div>
      </div>
      <!-- End Products -->
    </div>
    <!-- End Content -->
    <!-- Sidebar -->
    <div id="sidebar">
      <!-- Categories -->
      <div class="box categories">
      <?php
	  include "sidebar.php";
	  ?>  </div>
      <!-- End Categories -->
    </div>
    <!-- End Sidebar -->
    <div class="cl">&nbsp;</div>
  </div>
  <!-- End Main -->  
  
<?php
include "footer.php";
?>   